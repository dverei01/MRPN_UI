package mrpn.reachabilityAsp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

public class RunPython {
	public static void main(String[] args) {
		try {
			// create a ProcessBuilder for the Python program
			ProcessBuilder pb = new ProcessBuilder("python",
					"C:\\Users\\dvere\\PycharmProjects\\pythonProject\\test_ade\\test_work.py");

			// set the PYTHONUNBUFFERED environment variable to prevent buffering
			Map<String, String> env = pb.environment();
			env.put("PYTHONUNBUFFERED", "1");

			// start the process
			Process process = pb.start();

			// get the input stream of the process
			InputStream inputStream = process.getInputStream();

			// create a BufferedReader to read the output of the process
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

			// read the output of the process
			String line;
			
			while ((line = reader.readLine()) != null) {
				System.out.println(line);
			}
			// wait for the process to complete
			process.waitFor();
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
}
